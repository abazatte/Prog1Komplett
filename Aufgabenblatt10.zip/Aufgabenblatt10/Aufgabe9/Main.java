
public class Main {
	// Hauptprogramm
	public static void main(String[] args) {
		Pruefung klausur = new Pruefung();
		klausur.vorbereiten();
		klausur.durchfuehren();
		klausur.ergebnisseBekanntgeben();
	}
}
