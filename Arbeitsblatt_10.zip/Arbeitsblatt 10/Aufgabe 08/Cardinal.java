package aufg8;

public class Cardinal {

}
