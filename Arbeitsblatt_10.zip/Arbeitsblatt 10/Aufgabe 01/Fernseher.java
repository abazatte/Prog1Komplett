
public class Fernseher extends RundFunkEmpfangsGeraet{
	int kanal;
	
	Fernseher(){
		this.kanal = 1;
	}
	
	void waehleKanal(int x) {
		if(this.eingeschaltet = true) {
			this.kanal = x;
		}
		if(this.eingeschaltet = false) {
			System.out.println("System nicht eingeschaltet.");
		}
	}
}
