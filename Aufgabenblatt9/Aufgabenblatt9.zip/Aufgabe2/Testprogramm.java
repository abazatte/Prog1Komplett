
public class Testprogramm {
	public static void main(String[] args) {
		Enkel en = new Enkel(0);
		en.ergebnisse();
		
	}
	
}
